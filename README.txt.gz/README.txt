##HierBAPS functions converted to use protein sequences
##To read in a protein fasta multiple sequence alignment use package Biostrings
##ft <- readAAMultipleAlignment(filename, "fasta")
##can also take alternative formats of alignment
